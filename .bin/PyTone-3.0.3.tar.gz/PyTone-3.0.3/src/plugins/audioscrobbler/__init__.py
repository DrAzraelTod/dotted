import audioscrobbler

plugin = audioscrobbler.audioscrobblerplugin
config = audioscrobbler.audioscrobblerconfig
