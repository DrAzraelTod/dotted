# this is required to convert this directory into a package

""" this package contains a collection of services, i.e.
threads processing requests (and acting on events) of
other parts of PyTone. """

